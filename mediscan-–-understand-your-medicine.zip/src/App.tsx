import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Camera, 
  Upload, 
  Search, 
  History, 
  Settings, 
  LogOut, 
  Shield, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Download, 
  Share2, 
  Plus, 
  X, 
  Menu,
  ChevronRight,
  Stethoscope,
  Pill,
  Info,
  CreditCard,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged, signInWithPopup, signOut, User as FirebaseUser } from 'firebase/auth';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, googleProvider } from './firebase';
import { MedicineAnalysis, ScanHistory } from './types';
import axios from 'axios';
import imageCompression from 'browser-image-compression';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { GoogleGenAI } from "@google/genai";

// --- Components ---

const Header = ({ user }: { user: FirebaseUser | null }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <div className="bg-[#1D9E75] p-1.5 rounded-lg">
              <Stethoscope className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900 tracking-tight">MediScan</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-sm font-medium text-gray-600 hover:text-[#1D9E75] transition-colors">Home</Link>
            {user ? (
              <div className="flex items-center space-x-4">
                <Link to="/history" className="text-sm font-medium text-gray-600 hover:text-[#1D9E75] transition-colors">History</Link>
                <div className="flex items-center space-x-2 bg-gray-50 px-3 py-1.5 rounded-full border border-gray-100">
                  <img src={user.photoURL || ''} alt={user.displayName || ''} className="w-6 h-6 rounded-full" />
                  <span className="text-xs font-medium text-gray-700">{user.displayName?.split(' ')[0]}</span>
                  <button onClick={handleLogout} className="text-gray-400 hover:text-red-500 transition-colors">
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <button 
                onClick={handleLogin}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-[#1D9E75] hover:bg-[#168a65] transition-all shadow-sm"
              >
                Sign In
              </button>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-500 hover:text-gray-700">
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-gray-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-50 rounded-md">Home</Link>
              {user ? (
                <>
                  <Link to="/history" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-50 rounded-md">History</Link>
                  <button onClick={handleLogout} className="w-full text-left px-3 py-2 text-base font-medium text-red-600 hover:bg-red-50 rounded-md">Sign Out</button>
                </>
              ) : (
                <button onClick={handleLogin} className="w-full text-left px-3 py-2 text-base font-medium text-[#1D9E75] hover:bg-green-50 rounded-md">Sign In</button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

const Footer = () => (
  <footer className="bg-gray-50 border-t border-gray-200 pt-16 pb-8">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center space-x-2 mb-4">
            <div className="bg-[#1D9E75] p-1 rounded-lg">
              <Stethoscope className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-gray-900">MediScan</span>
          </div>
          <p className="text-gray-500 text-sm max-w-xs leading-relaxed">
            Empowering patients with instant, easy-to-understand medicine information using advanced AI technology.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4">Product</h4>
          <ul className="space-y-2">
            <li><Link to="/" className="text-sm text-gray-500 hover:text-[#1D9E75]">Home</Link></li>
            <li><Link to="/history" className="text-sm text-gray-500 hover:text-[#1D9E75]">History</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4">Legal</h4>
          <ul className="space-y-2">
            <li><span className="text-sm text-gray-500 hover:text-[#1D9E75] cursor-pointer">Privacy Policy</span></li>
            <li><span className="text-sm text-gray-500 hover:text-[#1D9E75] cursor-pointer">Terms of Service</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center">
        <p className="text-xs text-gray-400 mb-4 md:mb-0">
          © 2026 MediScan. All rights reserved.
        </p>
        <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-3 max-w-2xl">
          <p className="text-[10px] text-yellow-800 leading-tight">
            <span className="font-bold uppercase">Disclaimer:</span> MediScan is for informational purposes only and is not medical advice. Always consult a healthcare professional before taking any medication.
          </p>
        </div>
      </div>
    </div>
  </footer>
);

const Disclaimer = () => (
  <div className="fixed bottom-0 left-0 right-0 z-40 bg-yellow-400 p-3 shadow-2xl border-t border-yellow-500">
    <div className="max-w-7xl mx-auto px-4 flex items-start space-x-3">
      <AlertCircle className="w-5 h-5 text-yellow-900 shrink-0 mt-0.5" />
      <p className="text-xs sm:text-sm text-yellow-900 font-medium leading-tight">
        <span className="font-bold uppercase">⚠️ IMPORTANT:</span> This information is for general awareness only and is NOT medical advice. Always consult your doctor or pharmacist before taking any medicine. Do not self-medicate. MediScan is not responsible for any health decisions made based on this information.
      </p>
    </div>
  </div>
);

const CameraCapture = ({ onCapture, onCancel }: { onCapture: (file: File) => void, onCancel: () => void }) => {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' }, 
          audio: false 
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err) {
        console.error('Camera access error:', err);
        setError('Could not access camera. Please ensure you have granted permissions.');
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], 'camera_capture.jpg', { type: 'image/jpeg' });
            onCapture(file);
          }
        }, 'image/jpeg', 0.9);
      }
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-full h-64 bg-black rounded-xl overflow-hidden mb-4">
        {error ? (
          <div className="flex flex-col items-center justify-center h-full p-4 text-center">
            <AlertCircle className="w-8 h-8 text-red-500 mb-2" />
            <p className="text-xs text-white">{error}</p>
          </div>
        ) : (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            className="w-full h-full object-cover"
          />
        )}
        <canvas ref={canvasRef} className="hidden" />
      </div>
      <div className="flex space-x-4 w-full">
        <button 
          onClick={onCancel}
          className="flex-1 py-2 bg-gray-100 text-gray-700 rounded-lg font-bold text-sm hover:bg-gray-200 transition-colors"
        >
          Cancel
        </button>
        <button 
          onClick={capturePhoto}
          disabled={!!error}
          className="flex-1 py-2 bg-[#1D9E75] text-white rounded-lg font-bold text-sm hover:bg-[#168a65] transition-colors disabled:opacity-50"
        >
          Capture Photo
        </button>
      </div>
    </div>
  );
};

// --- Pages ---

const LandingPage = ({ user }: { user: FirebaseUser | null }) => {
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    setImage(file);
    const reader = new FileReader();
    reader.onloadend = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
    setError(null);
    setIsCameraOpen(false);
  };

  const handleAnalyze = async () => {
    if (!image) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      // Compress image
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1024,
        useWebWorker: true,
      };
      const compressedFile = await imageCompression(image, options);
      
      // Convert to base64 for Gemini
      const reader = new FileReader();
      reader.readAsDataURL(compressedFile);
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        
        try {
          const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
          const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: [
              {
                parts: [
                  {
                    inlineData: {
                      mimeType: "image/jpeg",
                      data: base64data,
                    },
                  },
                  {
                    text: `You are a medical information assistant helping patients understand their medicines. Analyze the medicine visible in the image and return structured information in simple, clear English that any patient can understand. 

Return your response strictly as a valid JSON object with these keys:
{
  "medicine_name": "string (brand name)",
  "generic_name": "string",
  "manufacturer": "string or null",
  "strength": "string (e.g. 500mg)",
  "medicine_type": "string (tablet/capsule/syrup/etc)",
  "uses": ["array of strings (conditions treated, in plain English)"],
  "dosage_schedule": {
    "times_per_day": 0,
    "morning": true,
    "afternoon": true,
    "night": true,
    "before_or_after_food": "string (before food / after food / with food / does not matter)",
    "take_with": "string (water / milk / food)",
    "course_duration": "string or null"
  },
  "side_effects": {
    "common": ["array of strings"],
    "serious": ["array of strings"],
    "what_to_do": "string"
  },
  "interactions": {
    "foods_to_avoid": ["array of strings"],
    "medicines_to_avoid": ["array of strings"],
    "lifestyle_warnings": ["array of strings"]
  },
  "storage": "string",
  "missed_dose": "string",
  "overdose_warning": "string",
  "recognized": true
}

If the image does not show a medicine clearly, return the same JSON with recognized set to false and all other fields as null.`,
                  },
                ],
              },
            ],
            config: {
              responseMimeType: "application/json",
            }
          });

          const analysis: MedicineAnalysis = JSON.parse(response.text);

          if (analysis.recognized) {
            // Save to history if user is logged in
            if (user) {
              await addDoc(collection(db, 'scans'), {
                userId: user.uid,
                timestamp: serverTimestamp(),
                medicineName: analysis.medicine_name,
                analysis: analysis
              });
            }
            
            // Navigate to results
            navigate('/results', { state: { analysis } });
          } else {
            setError('Medicine not recognized. Please upload a clearer photo showing the medicine name and packaging.');
          }
        } catch (err: any) {
          console.error('Analysis error:', err);
          setError('Failed to analyze medicine. Please check your API key and network connection.');
        } finally {
          setIsAnalyzing(false);
        }
      };
    } catch (err) {
      setError('Failed to process image. Please try again.');
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 w-96 h-96 bg-[#1D9E75] rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 tracking-tight mb-6">
              Understand Your <span className="text-[#1D9E75]">Medicine</span> Instantly
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-12 leading-relaxed">
              Upload a photo of any medicine strip, bottle, or box and get clear, simple information about usage, timing, and warnings.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-xl mx-auto"
          >
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-[#1D9E75] to-blue-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-white p-8 rounded-2xl border border-gray-100 shadow-xl">
                {isCameraOpen ? (
                  <CameraCapture 
                    onCapture={processFile} 
                    onCancel={() => setIsCameraOpen(false)} 
                  />
                ) : !preview ? (
                  <div className="space-y-4">
                    <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-gray-200 rounded-xl cursor-pointer hover:border-[#1D9E75] hover:bg-green-50/30 transition-all">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <div className="bg-green-50 p-3 rounded-full mb-3">
                          <Upload className="w-8 h-8 text-[#1D9E75]" />
                        </div>
                        <p className="mb-1 text-sm text-gray-700 font-semibold">Upload from device</p>
                        <p className="text-xs text-gray-500">JPG, PNG or WEBP</p>
                      </div>
                      <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                    </label>
                    
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-100"></div>
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-white px-2 text-gray-400">Or</span>
                      </div>
                    </div>

                    <button 
                      onClick={() => setIsCameraOpen(true)}
                      className="w-full py-4 border-2 border-[#1D9E75] text-[#1D9E75] rounded-xl font-bold flex items-center justify-center space-x-2 hover:bg-green-50 transition-all"
                    >
                      <Camera className="w-5 h-5" />
                      <span>Use Live Camera</span>
                    </button>
                  </div>
                ) : (
                  <div className="relative">
                    <img src={preview} alt="Preview" className="w-full h-64 object-cover rounded-xl" />
                    <button 
                      onClick={() => { setImage(null); setPreview(null); }}
                      className="absolute top-2 right-2 bg-white/90 p-1.5 rounded-full shadow-md text-gray-500 hover:text-red-500 transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                )}

                <button
                  disabled={!image || isAnalyzing}
                  onClick={handleAnalyze}
                  className={`mt-6 w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center space-x-2 transition-all shadow-lg ${
                    !image || isAnalyzing 
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                      : 'bg-[#1D9E75] text-white hover:bg-[#168a65] hover:shadow-[#1D9E75]/20'
                  }`}
                >
                  {isAnalyzing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>AI is analyzing...</span>
                    </>
                  ) : (
                    <>
                      <Search className="w-5 h-5" />
                      <span>Analyze Medicine</span>
                    </>
                  )}
                </button>
                
                <p className="mt-4 text-[10px] text-gray-400">
                  Your photo is analyzed instantly and never stored on our servers.
                </p>
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-start space-x-3 text-left"
              >
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <p className="text-sm text-red-700 font-medium">{error}</p>
              </motion.div>
            )}
          </motion.div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How it works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Get detailed medicine information in three simple steps.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { step: 1, title: 'Upload Photo', desc: 'Upload a photo of your medicine strip, bottle, or box.', icon: Camera },
              { step: 2, title: 'AI Identification', desc: 'AI instantly identifies and analyzes the medicine.', icon: Shield },
              { step: 3, title: 'Get Insights', desc: 'Get clear information about usage, timing, and warnings.', icon: Info },
            ].map((item) => (
              <div key={item.step} className="relative flex flex-col items-center text-center">
                <div className="bg-white w-20 h-20 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-center mb-6 relative z-10">
                  <item.icon className="w-10 h-10 text-[#1D9E75]" />
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#1D9E75] text-white rounded-full flex items-center justify-center font-bold text-sm border-4 border-gray-50">
                    {item.step}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why MediScan */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Instant Results', desc: 'No more searching through long pamphlets. Get answers in seconds.', icon: Clock },
              { title: 'Simple Language', desc: 'We translate complex medical jargon into easy-to-understand English.', icon: CheckCircle },
              { title: 'Privacy First', desc: 'Your photos are analyzed instantly and never stored on our servers.', icon: Shield },
            ].map((item, i) => (
              <div key={i} className="p-8 rounded-2xl border border-gray-100 hover:border-[#1D9E75]/20 hover:bg-green-50/10 transition-all">
                <item.icon className="w-8 h-8 text-[#1D9E75] mb-6" />
                <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              { q: 'Is this app a substitute for a doctor?', a: 'No. MediScan is for informational purposes only. Always consult a healthcare professional before taking any medication.' },
              { q: 'Which medicines can be scanned?', a: 'You can scan any packaged medicine, including strips, bottles, and boxes. Clear photos work best.' },
              { q: 'Is my photo stored?', a: 'No. Your photos are analyzed instantly and then discarded. We do not store your medical images.' },
              { q: 'How accurate is the information?', a: 'The information is generated by advanced AI. While highly accurate, you should always verify with a pharmacist or doctor.' },
              { q: 'Which languages are supported?', a: 'Currently, MediScan supports English only. We are working on adding more languages soon.' },
            ].map((item, i) => (
              <details key={i} className="group bg-white rounded-xl border border-gray-100 overflow-hidden">
                <summary className="flex justify-between items-center p-5 cursor-pointer font-semibold text-gray-900">
                  {item.q}
                  <ChevronRight className="w-5 h-5 text-gray-400 group-open:rotate-90 transition-transform" />
                </summary>
                <div className="px-5 pb-5 text-gray-500 text-sm leading-relaxed">
                  {item.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

const ResultsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const analysis: MedicineAnalysis = location.state?.analysis;
  const resultsRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!analysis) {
      navigate('/');
    }
    window.scrollTo(0, 0);
  }, [analysis, navigate]);

  if (!analysis) return null;

  const handleDownloadPDF = async () => {
    if (!resultsRef.current) return;
    const canvas = await html2canvas(resultsRef.current, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`${analysis.medicine_name.replace(/\s+/g, '_')}_analysis.pdf`);
  };

  const handleShare = () => {
    const text = `Check out this medicine analysis for ${analysis.medicine_name} on MediScan!`;
    if (navigator.share) {
      navigator.share({
        title: 'MediScan Results',
        text: text,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(text + ' ' + window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const handleSetReminder = () => {
    if ('Notification' in window) {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          alert('Reminders enabled! You will receive notifications for your doses.');
        }
      });
    } else {
      alert('Your browser does not support notifications.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 space-y-4 md:space-y-0">
          <button 
            onClick={() => navigate('/')}
            className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-[#1D9E75] transition-colors"
          >
            <ChevronRight className="w-4 h-4 rotate-180 mr-1" />
            Scan Another Medicine
          </button>
          <div className="flex items-center space-x-3">
            <button onClick={handleDownloadPDF} className="p-2.5 bg-white border border-gray-200 rounded-lg text-gray-600 hover:text-[#1D9E75] hover:border-[#1D9E75]/30 transition-all shadow-sm">
              <Download className="w-5 h-5" />
            </button>
            <button onClick={handleShare} className="p-2.5 bg-white border border-gray-200 rounded-lg text-gray-600 hover:text-[#1D9E75] hover:border-[#1D9E75]/30 transition-all shadow-sm">
              <Share2 className="w-5 h-5" />
            </button>
            <button onClick={handleSetReminder} className="inline-flex items-center px-4 py-2.5 bg-[#1D9E75] text-white rounded-lg text-sm font-bold hover:bg-[#168a65] transition-all shadow-md">
              <Clock className="w-4 h-4 mr-2" />
              Set Dose Reminder
            </button>
          </div>
        </div>

        <div ref={resultsRef} className="space-y-6">
          {/* Card 1: Identity */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-1">{analysis.medicine_name}</h2>
                <p className="text-lg text-gray-500 italic">{analysis.generic_name}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-xl">
                <Pill className="w-8 h-8 text-[#1D9E75]" />
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">Manufacturer</p>
                <p className="text-sm font-semibold text-gray-700">{analysis.manufacturer || 'Not visible'}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">Strength</p>
                <p className="text-sm font-semibold text-gray-700">{analysis.strength}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">Type</p>
                <p className="text-sm font-semibold text-gray-700 capitalize">{analysis.medicine_type}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">Status</p>
                <div className="flex items-center text-green-600 text-sm font-bold">
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Verified
                </div>
              </div>
            </div>
          </motion.div>

          {/* Card 2: Uses */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-blue-50 p-2 rounded-lg">
                <Stethoscope className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">What This Medicine Treats</h3>
            </div>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {analysis.uses.map((use, i) => (
                <li key={i} className="flex items-start space-x-3 bg-gray-50 p-4 rounded-xl border border-gray-100">
                  <CheckCircle className="w-5 h-5 text-[#1D9E75] shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-700 font-medium">{use}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Card 3: Dosage */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-orange-50 p-2 rounded-lg">
                <Clock className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">How and When to Take It</h3>
            </div>
            
            <div className="flex flex-wrap gap-4 mb-8">
              <div className="flex-1 min-w-[140px] bg-gray-50 p-4 rounded-xl border border-gray-100">
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-2">Frequency</p>
                <p className="text-lg font-bold text-gray-900">{analysis.dosage_schedule.times_per_day} times a day</p>
              </div>
              <div className="flex-1 min-w-[140px] bg-gray-50 p-4 rounded-xl border border-gray-100">
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-2">Timing</p>
                <p className="text-lg font-bold text-gray-900 capitalize">{analysis.dosage_schedule.before_or_after_food}</p>
              </div>
              <div className="flex-1 min-w-[140px] bg-gray-50 p-4 rounded-xl border border-gray-100">
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-2">Take With</p>
                <p className="text-lg font-bold text-gray-900 capitalize">{analysis.dosage_schedule.take_with}</p>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
              <p className="text-sm font-bold text-gray-900 mb-4">Daily Schedule</p>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Morning', icon: '🌅', active: analysis.dosage_schedule.morning },
                  { label: 'Afternoon', icon: '☀️', active: analysis.dosage_schedule.afternoon },
                  { label: 'Night', icon: '🌙', active: analysis.dosage_schedule.night },
                ].map((time) => (
                  <div key={time.label} className={`flex flex-col items-center p-4 rounded-xl border transition-all ${
                    time.active ? 'bg-white border-[#1D9E75] shadow-sm' : 'bg-gray-100/50 border-transparent opacity-40'
                  }`}>
                    <span className="text-2xl mb-2">{time.icon}</span>
                    <span className="text-xs font-bold text-gray-900">{time.label}</span>
                    {time.active && <CheckCircle className="w-4 h-4 text-[#1D9E75] mt-2" />}
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Card 4: Side Effects */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-purple-50 p-2 rounded-lg">
                <AlertCircle className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Side Effects</h3>
            </div>
            
            <div className="space-y-6">
              <div>
                <p className="text-sm font-bold text-gray-900 mb-3">Common Side Effects</p>
                <div className="flex flex-wrap gap-2">
                  {analysis.side_effects.common.map((effect, i) => (
                    <span key={i} className="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-medium rounded-full border border-gray-100">
                      {effect}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-100 p-5 rounded-xl">
                <p className="text-sm font-bold text-orange-900 mb-3 flex items-center">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  Serious Side Effects
                </p>
                <ul className="space-y-2">
                  {analysis.side_effects.serious.map((effect, i) => (
                    <li key={i} className="text-sm text-orange-800 flex items-start">
                      <span className="mr-2">•</span>
                      {effect}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-blue-50 border border-blue-100 p-5 rounded-xl">
                <p className="text-sm font-bold text-blue-900 mb-2">What to do if a side effect occurs</p>
                <p className="text-sm text-blue-800 leading-relaxed">{analysis.side_effects.what_to_do}</p>
              </div>
            </div>
          </motion.div>

          {/* Card 5: Interactions */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-red-50 p-2 rounded-lg">
                <X className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">What to Avoid</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <p className="text-sm font-bold text-gray-900">Foods to Avoid</p>
                <div className="space-y-2">
                  {analysis.interactions.foods_to_avoid.map((item, i) => (
                    <div key={i} className="flex items-center space-x-2 text-sm text-gray-600">
                      <div className="w-1.5 h-1.5 bg-red-400 rounded-full" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <p className="text-sm font-bold text-gray-900">Medicines to Avoid</p>
                <div className="space-y-2">
                  {analysis.interactions.medicines_to_avoid.map((item, i) => (
                    <div key={i} className="flex items-center space-x-2 text-sm text-gray-600">
                      <div className="w-1.5 h-1.5 bg-red-400 rounded-full" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-100">
              <p className="text-sm font-bold text-gray-900 mb-4">Lifestyle Warnings</p>
              <div className="flex flex-wrap gap-3">
                {analysis.interactions.lifestyle_warnings.map((item, i) => (
                  <div key={i} className="flex items-center space-x-2 px-4 py-2 bg-gray-50 rounded-xl border border-gray-100">
                    <AlertCircle className="w-4 h-4 text-orange-500" />
                    <span className="text-sm text-gray-700 font-medium">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Card 6: Instructions */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="flex items-center space-x-3 mb-6">
              <div className="bg-green-50 p-2 rounded-lg">
                <Info className="w-5 h-5 text-[#1D9E75]" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Important Instructions</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-50 p-5 rounded-xl border border-gray-100">
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-2">Storage</p>
                <p className="text-sm text-gray-700 leading-relaxed font-medium">{analysis.storage}</p>
              </div>
              <div className="bg-gray-50 p-5 rounded-xl border border-gray-100">
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-2">Missed Dose</p>
                <p className="text-sm text-gray-700 leading-relaxed font-medium">{analysis.missed_dose}</p>
              </div>
              <div className="bg-gray-50 p-5 rounded-xl border border-gray-100">
                <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-2">Overdose</p>
                <p className="text-sm text-gray-700 leading-relaxed font-medium">{analysis.overdose_warning}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <Disclaimer />
    </div>
  );
};

/*
const PricingPage = () => {
  const tiers = [
    {
      name: 'Free Plan',
      price: '$0',
      period: '/month',
      features: ['3 scans per day', 'Basic results', 'No PDF export', 'Web access only'],
      cta: 'Get Started Free',
      popular: false
    },
    {
      name: 'Pro Plan',
      price: '$1.19',
      period: '/month',
      features: ['Unlimited scans', 'PDF export', 'Dose reminders', 'Scan history', 'Priority support'],
      cta: 'Upgrade to Pro',
      popular: true
    },
    {
      name: 'Family Plan',
      price: '$12.99',
      period: '/year',
      features: ['Everything in Pro', 'Up to 5 family profiles', 'Shared medicine history', 'Advanced drug interactions'],
      cta: 'Get Family Plan',
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-white py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-gray-600">Choose the plan that fits your health needs.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier) => (
            <div 
              key={tier.name} 
              className={`relative p-8 rounded-3xl border ${
                tier.popular ? 'border-[#1D9E75] shadow-xl shadow-[#1D9E75]/10' : 'border-gray-100 shadow-sm'
              }`}
            >
              {tier.popular && (
                <div className="absolute top-0 right-8 -translate-y-1/2 bg-[#1D9E75] text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}
              <h3 className="text-xl font-bold text-gray-900 mb-2">{tier.name}</h3>
              <div className="flex items-baseline mb-8">
                <span className="text-4xl font-extrabold text-gray-900">{tier.price}</span>
                <span className="text-gray-500 ml-1">{tier.period}</span>
              </div>
              <ul className="space-y-4 mb-10">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="w-4 h-4 text-[#1D9E75] mr-3 shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
              <button className={`w-full py-4 rounded-xl font-bold transition-all ${
                tier.popular 
                  ? 'bg-[#1D9E75] text-white hover:bg-[#168a65]' 
                  : 'bg-gray-50 text-gray-900 hover:bg-gray-100'
              }`}>
                {tier.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
*/

const HistoryPage = ({ user }: { user: FirebaseUser | null }) => {
  const [history, setHistory] = useState<ScanHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    const q = query(
      collection(db, 'scans'),
      where('userId', '==', user.uid),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ScanHistory[];
      setHistory(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, navigate]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-10 h-10 border-4 border-[#1D9E75]/20 border-t-[#1D9E75] rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Your Scan History</h1>
          <Link to="/" className="inline-flex items-center text-sm font-bold text-[#1D9E75] hover:underline">
            <Plus className="w-4 h-4 mr-1" />
            New Scan
          </Link>
        </div>

        {history.length === 0 ? (
          <div className="bg-white p-12 rounded-2xl border border-gray-100 text-center">
            <div className="bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
              <History className="w-8 h-8 text-gray-300" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">No scans yet</h3>
            <p className="text-gray-500 mb-8">Your medicine scan history will appear here.</p>
            <Link to="/" className="inline-flex items-center px-6 py-3 bg-[#1D9E75] text-white rounded-xl font-bold hover:bg-[#168a65] transition-all">
              Start Your First Scan
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((item) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={() => navigate('/results', { state: { analysis: item.analysis } })}
                className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:border-[#1D9E75]/30 cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-50 p-3 rounded-xl group-hover:bg-[#1D9E75] transition-colors">
                      <Pill className="w-6 h-6 text-[#1D9E75] group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{item.medicineName}</h3>
                      <p className="text-xs text-gray-400">
                        {item.timestamp ? (
                          `${item.timestamp.toDate().toLocaleDateString()} at ${item.timestamp.toDate().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                        ) : (
                          'Just now...'
                        )}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-[#1D9E75] transition-colors" />
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="w-12 h-12 border-4 border-[#1D9E75]/10 border-t-[#1D9E75] rounded-full animate-spin" />
    </div>
  );

  return (
    <Router>
      <div className="flex flex-col min-h-screen font-sans selection:bg-[#1D9E75]/10 selection:text-[#1D9E75]">
        <Header user={user} />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<LandingPage user={user} />} />
            <Route path="/results" element={<ResultsPage />} />
            <Route path="/history" element={<HistoryPage user={user} />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
