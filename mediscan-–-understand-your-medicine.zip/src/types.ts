export interface MedicineAnalysis {
  medicine_name: string;
  generic_name: string;
  manufacturer: string | null;
  strength: string;
  medicine_type: string;
  uses: string[];
  dosage_schedule: {
    times_per_day: number;
    morning: boolean;
    afternoon: boolean;
    night: boolean;
    before_or_after_food: string;
    take_with: string;
    course_duration: string | null;
  };
  side_effects: {
    common: string[];
    serious: string[];
    what_to_do: string;
  };
  interactions: {
    foods_to_avoid: string[];
    medicines_to_avoid: string[];
    lifestyle_warnings: string[];
  };
  storage: string;
  missed_dose: string;
  overdose_warning: string;
  recognized: boolean;
}

export interface ScanHistory {
  id: string;
  userId: string;
  timestamp: any;
  medicineName: string;
  analysis: MedicineAnalysis;
}
